import React from 'react'
import ReactDOM from 'react-dom'
import PainelPerguntas from './components/PainelPerguntas'

ReactDOM.render(
    <PainelPerguntas />,
    document.getElementById('root')
)