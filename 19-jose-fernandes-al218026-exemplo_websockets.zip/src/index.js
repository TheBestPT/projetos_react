import react from 'react'
import ReactDom from 'react-dom'
import Mensseger from './components/Mensseger'
//import App from './App'
ReactDom.render(
    <Mensseger />,
    document.getElementById('root')
)