import React from 'react';
import ReactDOM from 'react-dom';

import Painel from './componentes/Aplicacao';
ReactDOM.render(
		<Painel />,
		document.getElementById('aplicacao')
	);









