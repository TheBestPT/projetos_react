import React from 'react'

export default class MeuComponente extends React.Component{
    render(){
        return (
            <>
                <header>Header</header>
                <main>Main Content</main>
            </>
        )
    }
}

/*
extendend form
<React.Fragment>
    <header>Header</header>
    <main>Main Content</main>
</React.Fragment>
*/