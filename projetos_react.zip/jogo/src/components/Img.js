import React from 'react'
import Darth from '../img/Darth-Vader.jpg'

export default function Img() {
    return <img src={Darth} alt='Darth'/>
}