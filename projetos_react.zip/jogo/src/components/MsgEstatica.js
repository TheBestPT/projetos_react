import React from 'react'

export default function MsgEstatica() {
    return (
        <span>
            Ola eu sou o Span 
        </span>
    )
}