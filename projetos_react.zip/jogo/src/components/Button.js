import React from 'react'

export default function Button() {
    return <button onClick={() => alert('Hello you bastard')}>Hello click me!!</button>
}