import React from 'react'
export default class Aplicacao extends React.Component{
     render(){
         return <h2>Via Componente Aplicacao!</h2>
     }
}

