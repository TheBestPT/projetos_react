import React from 'react'
export default class CountInterno extends React.Component{
    render(){
        return (
            <div>
                ola
            </div>
        )
    }
}